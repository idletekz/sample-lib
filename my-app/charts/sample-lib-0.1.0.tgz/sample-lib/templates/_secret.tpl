{{- define "sample-lib.secret" -}}
apiVersion: v1
kind: Secret
metadata:
  name: {{ .name }}
  namespace: {{ .namespace }}
type: Opaque
data:
{{- range $key, $value := .data }}
  {{ $key }}: {{ $value | b64enc }}
{{- end }}
{{- end }}
